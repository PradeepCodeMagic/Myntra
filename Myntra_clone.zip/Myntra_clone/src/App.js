import logo from './logo.svg';
import './App.css';
import './Custom.css';
import { Container } from 'react-bootstrap';
import Header from './Page/Header';
import Home from './Page/Home';


function App() {
  return (
    <>


  
    </>
  );
}

export default App;
